<?php
require('../php/config.php');
session_start();

// $_SERVER['REQUEST_METHOD'] = 'POST';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the request is to fetch credentials 
                 
    if (isset($_POST['fetchCredentials']) && $_POST['fetchCredentials'] === 'true') {
        echo json_encode([ 
            "status" => "success", 
            "user" => [ 
                "username" => $username1, 
                "password" => $password1,
                // "LEVEL_CAREER" => $LEVEL_CAREER,
                "email" => $email1
            ] 
        ]);
        exit;
    }

    $inputUsername = isset($_POST['username']) ? $_POST['username'] : '';
    $inputPassword = isset($_POST['password']) ? $_POST['password'] : '';

    if (empty($inputUsername) || empty($inputPassword)) {
        echo json_encode(["status" => "error", "message" => "Username and password are required."]);
        exit;
    }

    $postData = [
        'fnc' => 'authenUserLogin',
        'uname' => $inputUsername,
        'psword' => $inputPassword
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://192.168.4.246/request_cetificate/api/user-api.php");
    // curl_setopt($ch, CURLOPT_URL, "../api/user-api.php");
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded'
    ]);

    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        echo json_encode(["status" => "error", "message" => "API request failed: " . curl_error($ch)]);
        curl_close($ch);
        exit;
    }

    curl_close($ch);

    $responseData = json_decode($response, true);

    if (isset($responseData['HR_FNAME'])) {
        $_SESSION['user'] = $responseData;
    
        // Query to get user details from rq_user table
        $stmt = $conn->prepare("SELECT id, full_name, 
                                        email_address, 
                                        role,
                                        department,
                                        position 
                                FROM db_item
                                WHERE uname = ?");
        $stmt->bind_param("s", $inputUsername);
        $stmt->execute();
        $result = $stmt->get_result();

        $name_full = isset($responseData['SUB_SUB_LEADER']) ? $responseData['SUB_SUB_LEADER'] : '';
        $leader_name = normalizeName($responseData['SUB_SUB_LEADER']);


        if ($result->num_rows > 0) {
            // Get user details from rq_user table
            $row = $result->fetch_assoc();
            $id_user = $row['id_user']; 
            $full_name = normalizeName($row['full_name']);
            $email = $row['email_address']; 
            $role = $row['career_role']; 
            $work_group = $row['work_group']; 
            // Update `latest_login` in rq_user table
            $stmt = $conn->prepare("UPDATE rq_user SET latest_login = NOW() WHERE uname = ?");
            $stmt->bind_param("s", $inputUsername);
            if ($stmt->execute()) {
                // Store user details in session
                $_SESSION['id_user'] = $id_user;
                $_SESSION['career_role'] = $role;
                $_SESSION['email'] = $email;

                // echo "sss";
    
                // Return login success with LEVEL_CAREER and email
                echo json_encode([
                    "status" => "success",
                    "message" => "Login successful, latest_login updated.",
                    "id_user" => $id_user,
                    "user" => $responseData,
                    "role" => $role,
                    "email" => $email,
                    "work_group" => $work_group,
                    "leader_name" => $leader_name,
                    "fullname" => $full_name,
                    "name_full" => $name_full
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error updating latest_login: " . $conn->error]);
            }
        } else {
            // $result = $conn->query("SELECT MAX(CAST(id_user AS UNSIGNED)) AS max_id FROM rq_user");
            // $row = $result->fetch_assoc();
            $fname = isset($responseData['HR_FNAME']) ? $responseData['HR_FNAME'] : '';
            $full_name = normalizeName($fname);
            $position = isset($responseData['POSITION_IN_WORK']) ? $responseData['POSITION_IN_WORK'] : '';
            $department = isset($responseData['DEPARTMENT_NAME']) ? $responseData['DEPARTMENT_NAME'] : '';
            $work_group = isset($responseData['HR_DEPARTMENT_SUB_NAME']) ? $responseData['HR_DEPARTMENT_SUB_NAME'] : '';
            $mission = isset($responseData['HR_DEPARTMENT_SUB_SUB_NAME']) ? $responseData['HR_DEPARTMENT_SUB_SUB_NAME'] : '';
            $start_working = isset($responseData['HR_STARTWORK_DATE']) ? $responseData['HR_STARTWORK_DATE'] : '';
            $kind_type = isset($responseData['HR_KIND_TYPE_NAME']) ? $responseData['HR_KIND_TYPE_NAME'] : '';
            $email = isset($responseData['HR_EMAIL']) ? $responseData['HR_EMAIL'] : '';
            // $levelCareer = isset($responseData['LEVEL_CAREER']) ? $responseData['LEVEL_CAREER'] : '';
            $tel = ''; // Default phone number
            
            if($work_group === 'ไม่ทราบ' && $full_name === $leader_name){
                $levelCareer = 'หัวหน้างาน2';
            }else{
                $levelCareer = isset($responseData['LEVEL_CAREER']) ? $responseData['LEVEL_CAREER'] : '';
            }

            $sql = "INSERT INTO rq_user (full_name, uname, psword, position, department, work_group, mission, start_working, kind_type, latest_login, email_address, career_role)
            VALUES ('$fname', '$inputUsername', '$inputPassword', '$position', '$department', '$work_group', '$mission', '$start_working', '$kind_type', NOW(), '$email', '$levelCareer')";
           if ($conn->query($sql) === TRUE) {
                // Store user details in session
                $stmt = $conn->prepare("SELECT id_user, 
                                full_name, 
                                email_address, 
                                career_role 
                        FROM rq_user 
                        WHERE uname = ?");
                $stmt->bind_param("s", $inputUsername);
                $stmt->execute();
                $resultNewUser = $stmt->get_result();
                $row = $resultNewUser->fetch_assoc();
                $id_user = $row['id_user']; 
                $_SESSION['id_user'] = $row['id_user']; 
                $_SESSION['career_role'] = $row['career_role']; 
                $_SESSION['email'] = $row['email_address']; 

                
                echo json_encode([
                    "status" => "success",
                    "message" => "Login successful and user data saved.",
                    "user" => $responseData,
                    "role" => $levelCareer,
                    "email" => $email,
                    "work_group" => $work_group,
                    "leader_name" => $leader_name,
                    "fullname" => $full_name,
                    "name_full" => $name_full,
                    "id_user" => $id_user
                ]);
            } else {
                echo json_encode(["status" => "error", "message" => "Error saving user data: " . $conn->error]);
            }
        }
        $conn->close();
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid login credentials."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
function normalizeName($name) {
    $name = preg_replace('/\s+/', '', $name);
    $name = str_ireplace("นาย", "", $name);
    return strtolower($name);
}
?>
