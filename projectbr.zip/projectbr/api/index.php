<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(to bottom, #87CEEB, #ffffff);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .card-login {
            background: rgba(255, 255, 255, 0.8);
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .card-login img {
            margin-bottom: 1rem;
        }
        .form-control {
            margin-bottom: 1rem;
        }
        .btn-primary {
            width: 100%;
            border-radius: 20px;
        }
        .alert {
            margin-top: 1rem;
        }
        .error-message {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="card-login col-md-4">
        <img src="picture/haytai.png" alt="Hatyai Hospital" class="img-fluid" width="100" height="100">
        <h1 class="h5 mb-3">Login</h1>
        <form id="loginForm">
            <div class="input-group mb-3">
                <span class="input-group-text">
                    <img src="picture/person-circle.svg" alt="username-icon" width="20" height="20">
                </span>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username" required>
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text">
                    <img src="picture/lock-fill.svg" alt="password-icon" width="20" height="20">
                </span>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
        <div class="error-message" id="errorMessage"></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const loginForm = document.getElementById('loginForm');
        const errorMessage = document.getElementById('errorMessage');

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();

            try {
                const response = await fetch('./testtest.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: new URLSearchParams({ username, password })
                });
                console.log(response);

                const result = await response.json();
                console.log(result);
                if (result.status === 'success') {
                    console.log(result.user);
                    console.log(`ID User: ${result.id_user}`);
                    // Redirect based on LEVEL_CAREER
                    if (result.work_group === 'ไม่ทราบ' && result.leader_name === result.fullname) {
                        localStorage.setItem("leader", result.name_full);
                        window.location.href = `mainboss2.php?id_user=${result.id_user}`;
                    } else if (
                        result.role === 'หัวหน้าหน่วยงาน' || result.role === 'หัวหน้าภารกิจ' || result.role === 'หัวหน้ากลุ่มงาน'
                    ) {
                        window.location.href = `mainboss1.php?id_user=${result.id_user}`;
                    } else if (result.role === 'พนักงานทั่วไป') {
                        window.location.href = `message.php?id_user=${result.id_user}`;
                    } else {
                        // console.log('ไม่เข้าเงื่อนไขใดๆ');
                        // console.log('reload');
                        location.reload(); // Default redirection
                    }

                } else {
                    errorMessage.textContent = result.message;
                }
            } catch (error) {
                errorMessage.textContent = 'An error occurred. Please try again.';
                console.error(error);
            }
        });

    </script>
</body>
</html>
