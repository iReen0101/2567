<?php

session_start();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Line Notify</title>
    
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- style CSS-->
  <link rel="stylesheet" href="../../dist/css/style.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables/dataTables.bootstrap4.min.css">
  <!-- bootstrap-toggle -->
  <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
</head>

   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<style>
    @import url("https://fonts.googleapis.com/css?family=Trirong");




form {
   
    height: 300px;
    background: white;
    color: #000;
    font-family: "Trirong";
    font-size: large;
    font-weight: bold;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    box-shadow: 0px 20px 25px #02020233; 
    padding: 24px;
}


.form-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh; /* ใช้เพื่อให้ฟอร์มอยู่ตรงกลางแนวตั้ง */
    }
.form-group{
    margin-bottom: 100%;
}

input {
    width: 100%;
    padding: 70px;
    margin: 5px 0;
    border-radius: 10px solid #ccc;
    box-shadow: 7px 5px 2px #02020233;
    transition: trasform 0.3s ease, box-shadow 0.3s ease;
}

input:hover {
    transform: scale(1.05);
    box-shadow: 0px 0px 15px #0000004d;
}

input::placeholder {
    font-family: "Trirong";
}

label {
    margin-bottom: 5px;
}
.wrapper {
    display: flex;
            justify-content: center;
            align-items: center;
          
}

button {
    background: linear-gradient(to right, #f9ce34, #ee2a7b);
    color: white;
    padding: 10px 20px;
    border-radius: 12px;
    margin-top: 3px;
    font-size: inherit;
    cursor: pointer;
    font-family: "Trirong";
    transition: 
    transform 0.3 ease,
    box-shadow 0.3s ease;
}



</style>
</head>


    <?php if($_SESSION['role'] == 'admin')  ?>
   
       
         
<body class="hold-transition sidebar-mini">
    <div class="wrapperr">
    <?php include_once('../includes/sidebar.php') ?>
    

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- Content Header (Page header) -->
        <h1>Line Notify</h1>
        <hr>

        <form action="sentinfo.php" method="POST">
            <?php if(isset($_SESSION['success'])) {  ?>
            <div class="alert alert-success" role="alert">
               <?php 
               echo $_SESSION['success'];
               unset($_SESSION['success']);
               ?>
            </div>
            <?php } ?>

            <?php if(isset($_SESSION['error'])) {  ?>
            <div class="alert alert-danger" role="alert">
               <?php 
               echo $_SESSION['error'];
               unset($_SESSION['error']);
               ?>
            </div>
            <?php } ?>

            <div class="mb-3">
                <label for="email" class="form-label">Email address</label>
                <input type="email" class="form-control" name="email" aria-describedby="email">
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" name="fullname" aria-describedby="fullname">
            </div>
            
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>

</html>