<?php 
    header('Location: pages/dashboard');
?>