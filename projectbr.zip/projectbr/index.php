<?php 
    header('Location: src/login.php');
?>